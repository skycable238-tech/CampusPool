package com.example.myapplication.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.myapplication.repository.CampusPoolRepository
import com.example.myapplication.ui.screens.*

sealed class Screen(val route: String, val title: String, val icon: String) {
    object Login : Screen("login", "Login", "🔐")
    object Auth : Screen("auth", "Welcome", "🔑")
    object Feed : Screen("feed", "Find Rides", "🔍")
    object Offer : Screen("offer", "Offer Ride", "🚘")
    object MyRides : Screen("my_rides", "My Rides", "📋")
    object Profile : Screen("profile", "Profile", "👤")
    object Detail : Screen("detail/{rideId}", "Ride Details", "ℹ️") {
        fun createRoute(rideId: String) = "detail/$rideId"
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CampusPoolApp() {
    var currentScreen by remember { mutableStateOf<Screen>(Screen.Login) }
    var selectedRideId by remember { mutableStateOf<String?>(null) }
    val currentUser by CampusPoolRepository.getCurrentUser().collectAsState()

    val bottomNavItems = listOf(
        Screen.Feed,
        Screen.Offer,
        Screen.MyRides,
        Screen.Profile
    )

    Scaffold(
        topBar = {
            if (currentScreen != Screen.Login && currentScreen != Screen.Auth && currentScreen != Screen.Offer && selectedRideId == null) {
                TopAppBar(
                    title = {
                        Text(
                            text = "CampusPool",
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    },
                    actions = {
                        Surface(
                            shape = MaterialTheme.shapes.small,
                            color = MaterialTheme.colorScheme.primaryContainer,
                            modifier = Modifier.padding(end = 12.dp)
                        ) {
                            Text(
                                text = "Mode: ${currentUser.activeRole.name}",
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        }
                    }
                )
            }
        },
        bottomBar = {
            if (currentScreen != Screen.Login && currentScreen != Screen.Auth && selectedRideId == null) {
                NavigationBar {
                    bottomNavItems.forEach { screen ->
                        NavigationBarItem(
                            selected = currentScreen == screen,
                            onClick = {
                                selectedRideId = null
                                currentScreen = screen
                            },
                            icon = { Text(screen.icon, fontSize = 20.sp) },
                            label = { Text(screen.title) }
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        Surface(
            modifier = Modifier.padding(innerPadding)
        ) {
            val activeRideId = selectedRideId
            if (activeRideId != null) {
                RideDetailScreen(
                    rideId = activeRideId,
                    onBackClick = { selectedRideId = null },
                    onBookingSuccess = {
                        selectedRideId = null
                        currentScreen = Screen.MyRides
                    }
                )
            } else {
                when (currentScreen) {
                    Screen.Login -> LoginScreen(
                        onLoginSuccess = { currentScreen = Screen.Auth }
                    )
                    Screen.Auth -> AuthScreen(
                        onContinue = { currentScreen = Screen.Feed },
                        onSwitchAccount = { currentScreen = Screen.Login }
                    )
                    Screen.Feed -> RidesFeedScreen(
                        onRideSelected = { id -> selectedRideId = id },
                        onOfferRideClick = { currentScreen = Screen.Offer }
                    )
                    Screen.Offer -> OfferRideScreen(
                        onBackClick = { currentScreen = Screen.Feed },
                        onRidePublished = { currentScreen = Screen.Feed }
                    )
                    Screen.MyRides -> MyRidesScreen()
                    Screen.Profile -> ProfileScreen(
                        onLogoutClick = { currentScreen = Screen.Login }
                    )
                    else -> RidesFeedScreen(
                        onRideSelected = { id -> selectedRideId = id },
                        onOfferRideClick = { currentScreen = Screen.Offer }
                    )
                }
            }
        }
    }
}
