package com.example.myapplication.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.myapplication.repository.CampusPoolRepository
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OfferRideScreen(
    onBackClick: () -> Unit,
    onRidePublished: () -> Unit
) {
    val currentUser by CampusPoolRepository.getCurrentUser().collectAsState()

    var origin by remember { mutableStateOf("") }
    var destination by remember { mutableStateOf("Main Campus Gate 1") }
    var departureDate by remember { mutableStateOf("Today") }
    var departureTime by remember { mutableStateOf("05:30 PM") }
    var totalSeatsText by remember { mutableStateOf("3") }
    var fareText by remember { mutableStateOf("70.00") }
    var notes by remember { mutableStateOf("") }

    var originError by remember { mutableStateOf<String?>(null) }
    var destinationError by remember { mutableStateOf<String?>(null) }
    var seatsError by remember { mutableStateOf<String?>(null) }
    var fareError by remember { mutableStateOf<String?>(null) }

    val snackbarHostState = remember { SnackbarHostState() }
    val coroutineScope = rememberCoroutineScope()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Offer a New Ride") },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Text("←", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    }
                }
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)
                ),
                shape = RoundedCornerShape(12.dp)
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("🚘", fontSize = 24.sp)
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "Driver: ${currentUser.name}",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                        val vehicleInfo = currentUser.vehicle?.makeModel ?: "Registered Vehicle"
                        Text(
                            text = "$vehicleInfo • ${currentUser.vehicle?.licensePlate ?: "N/A"}",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            Text(
                text = "Route Information",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )

            Spacer(modifier = Modifier.height(8.dp))

            OutlinedTextField(
                value = origin,
                onValueChange = {
                    origin = it
                    originError = null
                },
                label = { Text("Pickup Origin Point *") },
                placeholder = { Text("e.g. Katipunan Avenue / SM North") },
                modifier = Modifier.fillMaxWidth(),
                isError = originError != null,
                supportingText = { originError?.let { Text(it, color = MaterialTheme.colorScheme.error) } },
                singleLine = true,
                shape = RoundedCornerShape(12.dp)
            )

            Spacer(modifier = Modifier.height(8.dp))

            OutlinedTextField(
                value = destination,
                onValueChange = {
                    destination = it
                    destinationError = null
                },
                label = { Text("Destination Point *") },
                placeholder = { Text("e.g. Main Campus Gate 1 / Tech Bldg") },
                modifier = Modifier.fillMaxWidth(),
                isError = destinationError != null,
                supportingText = { destinationError?.let { Text(it, color = MaterialTheme.colorScheme.error) } },
                singleLine = true,
                shape = RoundedCornerShape(12.dp)
            )

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "Schedule",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedTextField(
                    value = departureDate,
                    onValueChange = { departureDate = it },
                    label = { Text("Date") },
                    modifier = Modifier.weight(1f),
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp)
                )

                OutlinedTextField(
                    value = departureTime,
                    onValueChange = { departureTime = it },
                    label = { Text("Time") },
                    modifier = Modifier.weight(1f),
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "Capacity & Cost Sharing",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedTextField(
                    value = totalSeatsText,
                    onValueChange = {
                        totalSeatsText = it
                        seatsError = null
                    },
                    label = { Text("Available Seats (1-6) *") },
                    modifier = Modifier.weight(1f),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    isError = seatsError != null,
                    supportingText = { seatsError?.let { Text(it, color = MaterialTheme.colorScheme.error) } },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp)
                )

                OutlinedTextField(
                    value = fareText,
                    onValueChange = {
                        fareText = it
                        fareError = null
                    },
                    label = { Text("Fare / Seat (₱) *") },
                    modifier = Modifier.weight(1f),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    isError = fareError != null,
                    supportingText = { fareError?.let { Text(it, color = MaterialTheme.colorScheme.error) } },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp)
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            OutlinedTextField(
                value = notes,
                onValueChange = { notes = it },
                label = { Text("Additional Instructions / Pickup Notes") },
                placeholder = { Text("e.g. Wait at Gate 2 waiting shed; AC on; Cash/GCash accepted.") },
                modifier = Modifier.fillMaxWidth(),
                maxLines = 3,
                shape = RoundedCornerShape(12.dp)
            )

            Spacer(modifier = Modifier.height(24.dp))

            Button(
                onClick = {
                    var isValid = true

                    if (origin.isBlank()) {
                        originError = "Origin cannot be empty."
                        isValid = false
                    }

                    if (destination.isBlank()) {
                        destinationError = "Destination cannot be empty."
                        isValid = false
                    }

                    if (origin.isNotBlank() && origin.trim().equals(destination.trim(), ignoreCase = true)) {
                        destinationError = "Destination cannot be identical to origin."
                        isValid = false
                    }

                    val seatsVal = totalSeatsText.toIntOrNull()
                    if (seatsVal == null || seatsVal < 1 || seatsVal > 6) {
                        seatsError = "Enter seats between 1 and 6."
                        isValid = false
                    }

                    val fareVal = fareText.toDoubleOrNull()
                    if (fareVal == null || fareVal < 0 || fareVal > 500) {
                        fareError = "Fare must be ₱0 - ₱500."
                        isValid = false
                    }

                    if (isValid && seatsVal != null && fareVal != null) {
                        CampusPoolRepository.addRide(
                            origin = origin.trim(),
                            destination = destination.trim(),
                            departureDate = departureDate.ifBlank { "Today" },
                            departureTime = departureTime.ifBlank { "05:00 PM" },
                            totalSeats = seatsVal,
                            farePerSeat = fareVal,
                            notes = notes.trim()
                        )
                        coroutineScope.launch {
                            snackbarHostState.showSnackbar("Ride published successfully!")
                        }
                        onRidePublished()
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text(
                    text = "Publish Ride Offer",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}
