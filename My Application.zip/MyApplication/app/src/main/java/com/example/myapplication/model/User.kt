package com.example.myapplication.model

enum class UserRole {
    RIDER,
    DRIVER,
    BOTH
}

data class User(
    val id: String,
    val name: String,
    val email: String,
    val studentId: String,
    val phone: String,
    val role: UserRole = UserRole.BOTH,
    val activeRole: UserRole = UserRole.RIDER,
    val rating: Double = 4.9,
    val totalRidesCompleted: Int = 12,
    val vehicle: Vehicle? = null
)
