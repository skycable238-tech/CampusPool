package com.example.myapplication.model

enum class RideStatus {
    SCHEDULED,
    IN_PROGRESS,
    COMPLETED,
    CANCELLED
}

data class Ride(
    val id: String,
    val driverId: String,
    val driverName: String,
    val driverRating: Double = 4.8,
    val driverPhone: String = "0917-123-4567",
    val origin: String,
    val destination: String,
    val departureDate: String,
    val departureTime: String,
    val totalSeats: Int,
    val availableSeats: Int,
    val farePerSeat: Double,
    val vehicleModel: String,
    val vehiclePlate: String,
    val notes: String = "",
    val status: RideStatus = RideStatus.SCHEDULED
)
