package com.example.myapplication.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.myapplication.model.Booking
import com.example.myapplication.model.BookingStatus
import com.example.myapplication.model.Ride
import com.example.myapplication.model.RideStatus
import com.example.myapplication.repository.CampusPoolRepository
import kotlinx.coroutines.launch
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MyRidesScreen() {
    val bookings by CampusPoolRepository.getBookings().collectAsState()
    val rides by CampusPoolRepository.getRides().collectAsState()
    val currentUser by CampusPoolRepository.getCurrentUser().collectAsState()

    var selectedTabIndex by remember { mutableStateOf(0) }
    val tabTitles = listOf("🙋 My Bookings", "🚘 Offered Rides")

    val snackbarHostState = remember { SnackbarHostState() }
    val coroutineScope = rememberCoroutineScope()

    val myBookings = bookings.filter { it.riderId == currentUser.id }
    val myOfferedRides = rides.filter { it.driverId == currentUser.id }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            TabRow(selectedTabIndex = selectedTabIndex) {
                tabTitles.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTabIndex == index,
                        onClick = { selectedTabIndex = index },
                        text = { Text(title, fontWeight = FontWeight.SemiBold) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            when (selectedTabIndex) {
                0 -> {
                    if (myBookings.isEmpty()) {
                        EmptyStateView("You have no seat bookings yet.", "Search and book available rides from the feed!")
                    } else {
                        LazyColumn(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(horizontal = 16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp),
                            contentPadding = PaddingValues(bottom = 24.dp)
                        ) {
                            items(myBookings, key = { it.id }) { booking ->
                                BookingItemCard(
                                    booking = booking,
                                    onCancelClick = {
                                        val success = CampusPoolRepository.cancelBooking(booking.id)
                                        coroutineScope.launch {
                                            if (success) {
                                                snackbarHostState.showSnackbar("Booking cancelled and seat released.")
                                            } else {
                                                snackbarHostState.showSnackbar("Unable to cancel booking.")
                                            }
                                        }
                                    }
                                )
                            }
                        }
                    }
                }
                1 -> {
                    if (myOfferedRides.isEmpty()) {
                        EmptyStateView("You haven't offered any rides yet.", "Tap 'Offer a Ride' to publish seats for fellow students!")
                    } else {
                        LazyColumn(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(horizontal = 16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp),
                            contentPadding = PaddingValues(bottom = 24.dp)
                        ) {
                            items(myOfferedRides, key = { it.id }) { ride ->
                                OfferedRideItemCard(
                                    ride = ride,
                                    onCancelClick = {
                                        val success = CampusPoolRepository.cancelRide(ride.id)
                                        coroutineScope.launch {
                                            if (success) {
                                                snackbarHostState.showSnackbar("Offered ride cancelled.")
                                            }
                                        }
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun BookingItemCard(
    booking: Booking,
    onCancelClick: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Booking #${booking.id}",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = when (booking.status) {
                        BookingStatus.CONFIRMED -> Color(0xFFE8F5E9)
                        BookingStatus.CANCELLED -> MaterialTheme.colorScheme.errorContainer
                        BookingStatus.COMPLETED -> MaterialTheme.colorScheme.secondaryContainer
                    }
                ) {
                    Text(
                        text = booking.status.name,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = when (booking.status) {
                            BookingStatus.CONFIRMED -> Color(0xFF2E7D32)
                            BookingStatus.CANCELLED -> MaterialTheme.colorScheme.onErrorContainer
                            BookingStatus.COMPLETED -> MaterialTheme.colorScheme.onSecondaryContainer
                        }
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(text = "🟢 From: ${booking.origin}", fontWeight = FontWeight.Medium)
            Text(text = "🔴 To: ${booking.destination}", fontWeight = FontWeight.Bold)

            Spacer(modifier = Modifier.height(8.dp))

            Text(text = "👤 Driver: ${booking.driverName}")
            Text(text = "🚘 Vehicle: ${booking.vehicleDetails}")
            Text(text = "🕒 Schedule: ${booking.departureDate} at ${booking.departureTime}")
            Text(
                text = "💺 Seats: ${booking.seatsBooked} • Total Fare: ₱${String.format(Locale.getDefault(), "%.2f", booking.totalPrice)}",
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )

            if (booking.status == BookingStatus.CONFIRMED) {
                Spacer(modifier = Modifier.height(12.dp))
                OutlinedButton(
                    onClick = onCancelClick,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("Cancel Booking")
                }
            }
        }
    }
}

@Composable
fun OfferedRideItemCard(
    ride: Ride,
    onCancelClick: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Ride #${ride.id}",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = when (ride.status) {
                        RideStatus.SCHEDULED -> MaterialTheme.colorScheme.primaryContainer
                        RideStatus.IN_PROGRESS -> Color(0xFFFFF3E0)
                        RideStatus.COMPLETED -> MaterialTheme.colorScheme.secondaryContainer
                        RideStatus.CANCELLED -> MaterialTheme.colorScheme.errorContainer
                    }
                ) {
                    Text(
                        text = ride.status.name,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(text = "🟢 From: ${ride.origin}")
            Text(text = "🔴 To: ${ride.destination}", fontWeight = FontWeight.Bold)

            Spacer(modifier = Modifier.height(8.dp))

            Text(text = "🕒 Schedule: ${ride.departureDate} at ${ride.departureTime}")
            Text(text = "💺 Available Seats: ${ride.availableSeats} / ${ride.totalSeats}")
            Text(
                text = "💰 Fare per Seat: ₱${String.format(Locale.getDefault(), "%.2f", ride.farePerSeat)}",
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )

            if (ride.status == RideStatus.SCHEDULED) {
                Spacer(modifier = Modifier.height(12.dp))
                OutlinedButton(
                    onClick = onCancelClick,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("Cancel Ride Offer")
                }
            }
        }
    }
}

@Composable
fun EmptyStateView(title: String, subtitle: String) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("📋", fontSize = 48.sp)
            Spacer(modifier = Modifier.height(12.dp))
            Text(text = title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)
        }
    }
}
