package com.example.myapplication.repository

import com.example.myapplication.model.Booking
import com.example.myapplication.model.BookingStatus
import com.example.myapplication.model.Ride
import com.example.myapplication.model.RideStatus
import com.example.myapplication.model.User
import com.example.myapplication.model.UserRole
import com.example.myapplication.model.Vehicle
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object CampusPoolRepository {

    private val currentUser = MutableStateFlow(
        User(
            id = "USR-101",
            name = "Alex Santos",
            email = "alex.santos@campus.edu.ph",
            studentId = "2023-84585",
            phone = "0917-888-1234",
            role = UserRole.BOTH,
            activeRole = UserRole.RIDER,
            rating = 4.9,
            totalRidesCompleted = 14,
            vehicle = Vehicle(
                makeModel = "Toyota Vios Silver",
                color = "Silver",
                licensePlate = "ABC 1234",
                capacity = 4
            )
        )
    )

    private val initialRides = listOf(
        Ride(
            id = "RIDE-001",
            driverId = "USR-201",
            driverName = "Maria Clara",
            driverRating = 4.9,
            driverPhone = "0918-555-0192",
            origin = "Quezon City / Katipunan",
            destination = "Main Campus Gate 2",
            departureDate = "Today",
            departureTime = "07:30 AM",
            totalSeats = 4,
            availableSeats = 2,
            farePerSeat = 65.0,
            vehicleModel = "Honda City Black",
            vehiclePlate = "XYZ 8899",
            notes = "Pickup near LRT Katipunan Station. Non-smoking, air-conditioned.",
            status = RideStatus.SCHEDULED
        ),
        Ride(
            id = "RIDE-002",
            driverId = "USR-202",
            driverName = "Juan dela Cruz",
            driverRating = 4.7,
            driverPhone = "0920-333-8811",
            origin = "BGC / Taguig Terminal",
            destination = "Engineering Building",
            departureDate = "Today",
            departureTime = "08:15 AM",
            totalSeats = 3,
            availableSeats = 1,
            farePerSeat = 85.0,
            vehicleModel = "Toyota Vios White",
            vehiclePlate = "NDR 4321",
            notes = "Will stop briefly at C5 Shell Station if requested.",
            status = RideStatus.SCHEDULED
        ),
        Ride(
            id = "RIDE-003",
            driverId = "USR-203",
            driverName = "Samantha Reyes",
            driverRating = 5.0,
            driverPhone = "0999-111-2233",
            origin = "Main Campus Admin Hall",
            destination = "Makati Ayala Center",
            departureDate = "Today",
            departureTime = "05:15 PM",
            totalSeats = 4,
            availableSeats = 3,
            farePerSeat = 75.0,
            vehicleModel = "Mazda 3 Red",
            vehiclePlate = "NKK 9012",
            notes = "After classes ride. Drop off at One Ayala Terminal.",
            status = RideStatus.SCHEDULED
        ),
        Ride(
            id = "RIDE-004",
            driverId = "USR-204",
            driverName = "David Tan",
            driverRating = 4.8,
            driverPhone = "0915-777-6655",
            origin = "North EDSA Trinoma",
            destination = "IT & Tech Complex",
            departureDate = "Tomorrow",
            departureTime = "07:00 AM",
            totalSeats = 4,
            availableSeats = 4,
            farePerSeat = 60.0,
            vehicleModel = "Mitsubishi Xpander Grey",
            vehiclePlate = "CBK 5544",
            notes = "Spacious trunk for extra backpacks or campus project materials.",
            status = RideStatus.SCHEDULED
        ),
        Ride(
            id = "RIDE-005",
            driverId = "USR-101",
            driverName = "Alex Santos (You)",
            driverRating = 4.9,
            driverPhone = "0917-888-1234",
            origin = "Main Campus Gate 1",
            destination = "Ortigas Center / Megamall",
            departureDate = "Tomorrow",
            departureTime = "06:00 PM",
            totalSeats = 3,
            availableSeats = 2,
            farePerSeat = 70.0,
            vehicleModel = "Toyota Vios Silver",
            vehiclePlate = "ABC 1234",
            notes = "Leaving right after 5:30 PM lab class.",
            status = RideStatus.SCHEDULED
        )
    )

    private val initialBookings = listOf(
        Booking(
            id = "BKG-501",
            rideId = "RIDE-001",
            riderId = "USR-101",
            riderName = "Alex Santos",
            riderPhone = "0917-888-1234",
            origin = "Quezon City / Katipunan",
            destination = "Main Campus Gate 2",
            departureDate = "Today",
            departureTime = "07:30 AM",
            seatsBooked = 1,
            totalPrice = 65.0,
            driverName = "Maria Clara",
            vehicleDetails = "Honda City Black (XYZ 8899)",
            bookingTime = "06:45 AM Today",
            status = BookingStatus.CONFIRMED
        )
    )

    private val rides = MutableStateFlow<List<Ride>>(initialRides)
    private val bookings = MutableStateFlow<List<Booking>>(initialBookings)

    fun getCurrentUser(): StateFlow<User> = currentUser.asStateFlow()
    fun getRides(): StateFlow<List<Ride>> = rides.asStateFlow()
    fun getBookings(): StateFlow<List<Booking>> = bookings.asStateFlow()

    fun loginUser(email: String, studentId: String) {
        val nameParts = email.substringBefore("@")
            .split(".", "_", "-")
            .filter { it.isNotBlank() }
            .map { word -> word.replaceFirstChar { if (it.isLowerCase()) it.titlecase(Locale.getDefault()) else it.toString() } }

        val formattedName = if (nameParts.isNotEmpty()) nameParts.joinToString(" ") else "Student User"

        currentUser.value = currentUser.value.copy(
            email = email,
            studentId = studentId,
            name = formattedName
        )
    }

    fun switchActiveRole(role: UserRole) {
        currentUser.value = currentUser.value.copy(activeRole = role)
    }

    fun getRideById(id: String): Ride? {
        return rides.value.find { it.id == id }
    }

    fun addRide(
        origin: String,
        destination: String,
        departureDate: String,
        departureTime: String,
        totalSeats: Int,
        farePerSeat: Double,
        notes: String
    ): Boolean {
        val user = currentUser.value
        val vehicle = user.vehicle ?: Vehicle("Personal Car", "White", "TEMP-123", 4)
        val newRide = Ride(
            id = "RIDE-${System.currentTimeMillis().toString().takeLast(4)}",
            driverId = user.id,
            driverName = "${user.name} (You)",
            driverRating = user.rating,
            driverPhone = user.phone,
            origin = origin,
            destination = destination,
            departureDate = departureDate,
            departureTime = departureTime,
            totalSeats = totalSeats,
            availableSeats = totalSeats,
            farePerSeat = farePerSeat,
            vehicleModel = vehicle.makeModel,
            vehiclePlate = vehicle.licensePlate,
            notes = notes,
            status = RideStatus.SCHEDULED
        )
        rides.value = listOf(newRide) + rides.value
        return true
    }

    fun bookSeat(rideId: String, seatsToBook: Int): Pair<Boolean, String> {
        val currentRideList = rides.value
        val rideIndex = currentRideList.indexOfFirst { it.id == rideId }

        if (rideIndex == -1) {
            return Pair(false, "Ride not found.")
        }

        val targetRide = currentRideList[rideIndex]

        if (targetRide.availableSeats < seatsToBook) {
            return Pair(false, "Not enough available seats left on this ride.")
        }

        val user = currentUser.value
        if (targetRide.driverId == user.id) {
            return Pair(false, "You cannot book your own offered ride.")
        }

        val existingBooking = bookings.value.find { it.rideId == rideId && it.riderId == user.id && it.status == BookingStatus.CONFIRMED }
        if (existingBooking != null) {
            return Pair(false, "You already have an active booking for this ride.")
        }

        val updatedAvailableSeats = targetRide.availableSeats - seatsToBook
        val updatedRide = targetRide.copy(availableSeats = updatedAvailableSeats)

        val updatedRideList = currentRideList.toMutableList()
        updatedRideList[rideIndex] = updatedRide
        rides.value = updatedRideList

        val currentTime = SimpleDateFormat("hh:mm a 'Today'", Locale.getDefault()).format(Date())
        val newBooking = Booking(
            id = "BKG-${System.currentTimeMillis().toString().takeLast(4)}",
            rideId = rideId,
            riderId = user.id,
            riderName = user.name,
            riderPhone = user.phone,
            origin = targetRide.origin,
            destination = targetRide.destination,
            departureDate = targetRide.departureDate,
            departureTime = targetRide.departureTime,
            seatsBooked = seatsToBook,
            totalPrice = seatsToBook * targetRide.farePerSeat,
            driverName = targetRide.driverName,
            vehicleDetails = "${targetRide.vehicleModel} (${targetRide.vehiclePlate})",
            bookingTime = currentTime,
            status = BookingStatus.CONFIRMED
        )

        bookings.value = listOf(newBooking) + bookings.value
        return Pair(true, "Successfully booked $seatsToBook seat(s)!")
    }

    fun cancelBooking(bookingId: String): Boolean {
        val currentBookingList = bookings.value
        val bookingIndex = currentBookingList.indexOfFirst { it.id == bookingId }
        if (bookingIndex == -1) return false

        val targetBooking = currentBookingList[bookingIndex]
        if (targetBooking.status == BookingStatus.CANCELLED) return false

        val updatedBooking = targetBooking.copy(status = BookingStatus.CANCELLED)
        val mutableBookings = currentBookingList.toMutableList()
        mutableBookings[bookingIndex] = updatedBooking
        bookings.value = mutableBookings

        // Restore seats in Ride
        val currentRideList = rides.value
        val rideIndex = currentRideList.indexOfFirst { it.id == targetBooking.rideId }
        if (rideIndex != -1) {
            val ride = currentRideList[rideIndex]
            val restoredSeats = (ride.availableSeats + targetBooking.seatsBooked).coerceAtMost(ride.totalSeats)
            val updatedRide = ride.copy(availableSeats = restoredSeats)
            val mutableRides = currentRideList.toMutableList()
            mutableRides[rideIndex] = updatedRide
            rides.value = mutableRides
        }

        return true
    }

    fun cancelRide(rideId: String): Boolean {
        val currentRideList = rides.value
        val rideIndex = currentRideList.indexOfFirst { it.id == rideId }
        if (rideIndex == -1) return false

        val ride = currentRideList[rideIndex]
        val updatedRide = ride.copy(status = RideStatus.CANCELLED)
        val mutableRides = currentRideList.toMutableList()
        mutableRides[rideIndex] = updatedRide
        rides.value = mutableRides

        // Cancel associated bookings
        val updatedBookings = bookings.value.map { b ->
            if (b.rideId == rideId && b.status == BookingStatus.CONFIRMED) {
                b.copy(status = BookingStatus.CANCELLED)
            } else b
        }
        bookings.value = updatedBookings

        return true
    }
}
