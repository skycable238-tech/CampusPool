package com.example.myapplication.model

enum class BookingStatus {
    CONFIRMED,
    CANCELLED,
    COMPLETED
}

data class Booking(
    val id: String,
    val rideId: String,
    val riderId: String,
    val riderName: String,
    val riderPhone: String,
    val origin: String,
    val destination: String,
    val departureDate: String,
    val departureTime: String,
    val seatsBooked: Int,
    val totalPrice: Double,
    val driverName: String,
    val vehicleDetails: String,
    val bookingTime: String,
    val status: BookingStatus = BookingStatus.CONFIRMED
)
