package com.example.myapplication.model

data class Vehicle(
    val makeModel: String,
    val color: String,
    val licensePlate: String,
    val capacity: Int = 4
)
