package com.ucbanilad.campuspool.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.ucbanilad.campuspool.databinding.ItemRideBinding
import com.ucbanilad.campuspool.model.Ride
import com.ucbanilad.campuspool.model.RideStatus

/** Passenger "Browse rides" list. FULL rides are greyed out. */
class RideAdapter(private val onClick: (Ride) -> Unit) : RecyclerView.Adapter<RideAdapter.VH>() {
    private var items: List<Ride> = emptyList()

    fun submit(list: List<Ride>) { items = list; notifyDataSetChanged() }

    class VH(val b: ItemRideBinding) : RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(ItemRideBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun getItemCount() = items.size

    override fun onBindViewHolder(h: VH, position: Int) {
        val r = items[position]
        val ctx = h.b.root.context
        h.b.tvRoute.text = Ui.route(r)
        h.b.tvTime.text = Ui.dateTime(r.departureAt)
        h.b.tvDriver.text = "Driver: ${r.driverName} · Meet: ${r.meetingPoint}"
        h.b.tvSeats.text = Ui.seatsText(r)
        h.b.tvFare.text = Ui.fare(r.farePerSeat)
        Ui.badge(h.b.tvStatus, r.status.name, Ui.rideColor(ctx, r.status))
        Ui.seatMeter(h.b.seatMeter, r)
        h.b.root.alpha = if (r.status == RideStatus.FULL) 0.55f else 1f
        h.b.root.setOnClickListener { onClick(r) }
    }
}
