package com.ucbanilad.campuspool.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.ucbanilad.campuspool.data.MockRepository
import com.ucbanilad.campuspool.databinding.ItemRequestRowBinding
import com.ucbanilad.campuspool.model.RequestStatus
import com.ucbanilad.campuspool.model.RideRequest

/** Used twice in Manage Ride: pending requests (Accept/Decline) and accepted passengers (contact). */
class RideRequestAdapter(
    private val onAccept: (RideRequest) -> Unit,
    private val onDecline: (RideRequest) -> Unit
) : RecyclerView.Adapter<RideRequestAdapter.VH>() {
    private var items: List<RideRequest> = emptyList()
    private var canAccept = true

    /** [canAccept] is false when the ride is FULL, so the Accept buttons are disabled (BR-03). */
    fun submit(list: List<RideRequest>, canAccept: Boolean) {
        items = list; this.canAccept = canAccept; notifyDataSetChanged()
    }

    class VH(val b: ItemRequestRowBinding) : RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(ItemRequestRowBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun getItemCount() = items.size

    override fun onBindViewHolder(h: VH, position: Int) {
        val q = items[position]
        h.b.tvName.text = q.passengerName
        Ui.badge(h.b.tvStatus, q.status.name, Ui.requestColor(h.b.root.context, q.status))
        val pending = q.status == RequestStatus.PENDING
        val contact = MockRepository.getUser(q.passengerId)?.contactNumber.orEmpty()
        h.b.tvContact.text = if (pending) "Requested 1 seat" else "Contact: ${contact.ifBlank { "not provided" }}"
        h.b.actions.visibility = if (pending) View.VISIBLE else View.GONE
        h.b.btnAccept.isEnabled = canAccept
        h.b.btnAccept.setOnClickListener { onAccept(q) }
        h.b.btnDecline.setOnClickListener { onDecline(q) }
    }
}
