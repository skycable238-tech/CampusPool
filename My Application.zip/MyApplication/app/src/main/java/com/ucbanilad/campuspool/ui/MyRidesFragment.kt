package com.ucbanilad.campuspool.ui

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.ucbanilad.campuspool.data.MockRepository
import com.ucbanilad.campuspool.databinding.FragmentMyRidesBinding

class MyRidesFragment : Fragment() {
    private var _b: FragmentMyRidesBinding? = null
    private val b get() = _b!!

    private val adapter = MyRideAdapter { ride ->
        startActivity(Intent(requireContext(), ManageRideActivity::class.java)
            .putExtra(ManageRideActivity.EXTRA_RIDE_ID, ride.rideId))
    }

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        _b = FragmentMyRidesBinding.inflate(i, c, false)
        b.rvRides.layoutManager = LinearLayoutManager(requireContext())
        b.rvRides.adapter = adapter
        b.swHistory.setOnCheckedChangeListener { _, _ -> refresh() }
        b.fabPost.setOnClickListener { startActivity(Intent(requireContext(), PostRideActivity::class.java)) }
        return b.root
    }

    override fun onResume() {
        super.onResume()
        requireActivity().title = "My rides"
        refresh()
    }

    private fun refresh() {
        val u = MockRepository.currentUser ?: return
        val list = MockRepository.ridesOfDriver(u.userId, b.swHistory.isChecked)
        adapter.submit(list)
        b.tvEmpty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
    }

    override fun onDestroyView() { super.onDestroyView(); _b = null }
}
