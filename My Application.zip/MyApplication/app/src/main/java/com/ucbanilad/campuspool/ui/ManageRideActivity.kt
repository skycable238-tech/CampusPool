package com.ucbanilad.campuspool.ui

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.snackbar.Snackbar
import com.ucbanilad.campuspool.data.MockRepository
import com.ucbanilad.campuspool.databinding.ActivityManageRideBinding
import com.ucbanilad.campuspool.model.RequestStatus
import com.ucbanilad.campuspool.model.RideStatus

class ManageRideActivity : AppCompatActivity() {
    companion object { const val EXTRA_RIDE_ID = "extra_ride_id" }

    private lateinit var b: ActivityManageRideBinding
    private lateinit var rideId: String

    private val pendingAdapter = RideRequestAdapter(
        onAccept = { toast(MockRepository.acceptRequest(it.requestId).message) },
        onDecline = { toast(MockRepository.declineRequest(it.requestId).message) }
    )
    private val acceptedAdapter = RideRequestAdapter({}, {})

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityManageRideBinding.inflate(layoutInflater)
        setContentView(b.root)
        title = "Manage ride"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        rideId = intent.getStringExtra(EXTRA_RIDE_ID) ?: run { finish(); return }

        b.rvPending.layoutManager = LinearLayoutManager(this)
        b.rvPending.adapter = pendingAdapter
        b.rvAccepted.layoutManager = LinearLayoutManager(this)
        b.rvAccepted.adapter = acceptedAdapter

        b.btnEdit.setOnClickListener {
            startActivity(Intent(this, PostRideActivity::class.java).putExtra(PostRideActivity.EXTRA_RIDE_ID, rideId))
        }
        b.btnComplete.setOnClickListener { toast(MockRepository.completeRide(rideId).message) }
        b.btnCancelRide.setOnClickListener {
            MaterialAlertDialogBuilder(this)
                .setTitle("Cancel this ride?")
                .setMessage("All pending and accepted requests will be cancelled.")
                .setPositiveButton("Cancel ride") { _, _ -> toast(MockRepository.cancelRide(rideId).message) }
                .setNegativeButton("Keep ride", null)
                .show()
        }
    }

    override fun onResume() { super.onResume(); render() }

    override fun onSupportNavigateUp(): Boolean { finish(); return true }

    private fun toast(msg: String) {
        Snackbar.make(b.root, msg, Snackbar.LENGTH_LONG).show()
        render()
    }

    private fun render() {
        val r = MockRepository.getRide(rideId) ?: run { finish(); return }
        val active = r.status == RideStatus.OPEN || r.status == RideStatus.FULL
        val departed = r.departureAt <= System.currentTimeMillis()

        b.tvRoute.text = Ui.route(r)
        b.tvTime.text = "${Ui.dateTime(r.departureAt)} · Meet: ${r.meetingPoint} · ${Ui.fare(r.farePerSeat)}"
        Ui.badge(b.tvStatus, r.status.name, Ui.rideColor(this, r.status))
        b.tvSeats.text = "${r.totalSeats - r.availableSeats} of ${r.totalSeats} seats taken · ${r.availableSeats} left"
        Ui.seatMeter(b.seatMeter, r)
        b.tvBanner.visibility = if (r.status == RideStatus.FULL) View.VISIBLE else View.GONE
        b.tvBanner.text = "Capacity reached. Accept is disabled and new requests are blocked."

        val pending = MockRepository.requestsOfRide(rideId, RequestStatus.PENDING)
        val accepted = MockRepository.requestsOfRide(rideId, RequestStatus.ACCEPTED)
        val canAccept = active && !departed && r.availableSeats > 0
        pendingAdapter.submit(pending, canAccept)
        acceptedAdapter.submit(accepted, false)
        b.tvNoPending.visibility = if (pending.isEmpty()) View.VISIBLE else View.GONE
        b.tvNoAccepted.visibility = if (accepted.isEmpty()) View.VISIBLE else View.GONE

        b.btnEdit.isEnabled = active && !departed
        b.btnCancelRide.isEnabled = active && !departed
        b.btnComplete.isEnabled = active && departed
        b.tvHint.text = when {
            !active -> "This ride is ${r.status.name.lowercase()} and is read-only."
            departed -> "Departure time has passed. You can mark this ride completed."
            else -> "Rides can be edited or cancelled before departure and marked completed afterwards."
        }
    }
}
