package com.ucbanilad.campuspool.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.google.android.material.snackbar.Snackbar
import com.ucbanilad.campuspool.data.MockRepository
import com.ucbanilad.campuspool.databinding.FragmentProfileBinding
import com.ucbanilad.campuspool.model.Role
import com.ucbanilad.campuspool.model.Vehicle

class ProfileFragment : Fragment() {
    private var _b: FragmentProfileBinding? = null
    private val b get() = _b!!

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        _b = FragmentProfileBinding.inflate(i, c, false)
        val u = MockRepository.currentUser
        if (u != null) {
            b.tvName.text = u.fullName
            b.tvInfo.text = "${u.email}\nStudent ID: ${u.studentId}\nRole: ${u.role.name.lowercase().replaceFirstChar { it.uppercase() }}"
            b.etContact.setText(u.contactNumber)
            val isDriver = u.role == Role.DRIVER
            b.vehicleGroup.visibility = if (isDriver) View.VISIBLE else View.GONE
            u.vehicle?.let {
                b.etVehicleModel.setText(it.model)
                b.etVehicleColor.setText(it.color)
                b.etVehiclePlate.setText(it.plateNumber)
            }
        }
        b.btnSave.setOnClickListener {
            val v = Vehicle(b.etVehicleModel.text.toString().trim(), b.etVehicleColor.text.toString().trim(),
                b.etVehiclePlate.text.toString().trim())
            val out = MockRepository.updateProfile(b.etContact.text.toString(), v)
            Snackbar.make(b.root, out.message, Snackbar.LENGTH_SHORT).show()
        }
        b.btnLogout.setOnClickListener { (requireActivity() as MainActivity).logout() }
        return b.root
    }

    override fun onResume() { super.onResume(); requireActivity().title = "Profile" }

    override fun onDestroyView() { super.onDestroyView(); _b = null }
}
