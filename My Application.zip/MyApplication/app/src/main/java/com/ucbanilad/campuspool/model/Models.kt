package com.ucbanilad.campuspool.model

enum class Role { DRIVER, PASSENGER }
enum class RideStatus { OPEN, FULL, COMPLETED, CANCELLED }
enum class RequestStatus { PENDING, ACCEPTED, DECLINED, CANCELLED }

data class Vehicle(
    val model: String,
    val color: String,
    val plateNumber: String
)

data class User(
    val userId: String,
    val fullName: String,
    val email: String,
    val studentId: String,
    val contactNumber: String,
    val role: Role,
    val vehicle: Vehicle?,          // drivers only
    val createdAt: Long
)

data class Ride(
    val rideId: String,
    val driverId: String,
    val driverName: String,
    var origin: String,
    var destination: String,
    var meetingPoint: String,
    var departureAt: Long,
    var totalSeats: Int,
    var availableSeats: Int,        // live seat counter (capacity rule)
    var farePerSeat: Double,
    var notes: String,
    var status: RideStatus,
    val createdAt: Long
)

data class RideRequest(
    val requestId: String,
    val rideId: String,
    val passengerId: String,
    val passengerName: String,
    val driverId: String,
    var status: RequestStatus,
    val createdAt: Long,
    var respondedAt: Long? = null
)
