package com.ucbanilad.campuspool.ui

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.ucbanilad.campuspool.R
import com.ucbanilad.campuspool.data.MockRepository
import com.ucbanilad.campuspool.databinding.FragmentHomeBinding
import com.ucbanilad.campuspool.model.RequestStatus
import com.ucbanilad.campuspool.model.Role

class HomeFragment : Fragment() {
    private var _b: FragmentHomeBinding? = null
    private val b get() = _b!!

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        _b = FragmentHomeBinding.inflate(i, c, false)
        return b.root
    }

    override fun onResume() {
        super.onResume()
        requireActivity().title = "Home"
        val u = MockRepository.currentUser ?: return
        val main = requireActivity() as MainActivity
        b.tvGreeting.text = "Hello, ${u.fullName.substringBefore(' ')}!"
        if (u.role == Role.PASSENGER) {
            b.tvRole.text = "Student Passenger"
            val mine = MockRepository.requestsOfPassenger(u.userId)
            b.tvStat1.text = mine.count { it.status == RequestStatus.PENDING }.toString()
            b.tvStat1Label.text = "Pending requests"
            b.tvStat2.text = mine.count { it.status == RequestStatus.ACCEPTED }.toString()
            b.tvStat2Label.text = "Accepted rides"
            b.btnPrimary.text = "Find a ride"
            b.btnPrimary.setOnClickListener { main.navigateTo(R.id.nav_browse) }
            b.btnSecondary.text = "My requests"
            b.btnSecondary.setOnClickListener { main.navigateTo(R.id.nav_requests) }
        } else {
            b.tvRole.text = "Student Driver"
            b.tvStat1.text = MockRepository.ridesOfDriver(u.userId, false).size.toString()
            b.tvStat1Label.text = "Active rides"
            b.tvStat2.text = MockRepository.pendingCountForDriver(u.userId).toString()
            b.tvStat2Label.text = "Pending requests"
            b.btnPrimary.text = "Post a ride"
            b.btnPrimary.setOnClickListener { startActivity(Intent(requireContext(), PostRideActivity::class.java)) }
            b.btnSecondary.text = "Manage my rides"
            b.btnSecondary.setOnClickListener { main.navigateTo(R.id.nav_rides) }
        }
    }

    override fun onDestroyView() { super.onDestroyView(); _b = null }
}
