package com.ucbanilad.campuspool.ui

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.snackbar.Snackbar
import com.ucbanilad.campuspool.data.MockRepository
import com.ucbanilad.campuspool.databinding.ActivityRegisterBinding
import com.ucbanilad.campuspool.model.Role

class RegisterActivity : AppCompatActivity() {
    private lateinit var b: ActivityRegisterBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityRegisterBinding.inflate(layoutInflater)
        setContentView(b.root)
        title = "Create account"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        b.btnRegister.setOnClickListener {
            val role = if (b.rbDriver.isChecked) Role.DRIVER else Role.PASSENGER
            val out = MockRepository.register(
                b.etName.text.toString(), b.etStudentId.text.toString(),
                b.etEmail.text.toString().trim(), b.etPassword.text.toString(), role
            )
            if (!out.ok) {
                Snackbar.make(b.root, out.message, Snackbar.LENGTH_LONG).show()
                return@setOnClickListener
            }
            startActivity(
                Intent(this, MainActivity::class.java)
                    .putExtra(MainActivity.EXTRA_ROLE, role.name)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
            )
        }
    }

    override fun onSupportNavigateUp(): Boolean { finish(); return true }
}
