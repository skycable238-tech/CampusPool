package com.ucbanilad.campuspool.ui

import android.content.Context
import android.content.res.ColorStateList
import android.widget.TextView
import androidx.core.content.ContextCompat
import com.google.android.material.progressindicator.LinearProgressIndicator
import com.ucbanilad.campuspool.R
import com.ucbanilad.campuspool.model.RequestStatus
import com.ucbanilad.campuspool.model.Ride
import com.ucbanilad.campuspool.model.RideStatus
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Ui {
    private val dateTimeFmt = SimpleDateFormat("EEE, MMM d · h:mm a", Locale.getDefault())
    private val dayFmt = SimpleDateFormat("EEE, MMM d, yyyy", Locale.getDefault())

    fun dateTime(ms: Long): String = dateTimeFmt.format(Date(ms))
    fun day(ms: Long): String = dayFmt.format(Date(ms))
    fun fare(v: Double): String = if (v <= 0) "Free" else "₱" + String.format(Locale.US, "%.2f", v)
    fun route(r: Ride) = "${r.origin} → ${r.destination}"

    fun seatsText(r: Ride): String = when (r.status) {
        RideStatus.FULL -> "No seats left (${r.totalSeats} of ${r.totalSeats} taken)"
        else -> "${r.availableSeats} of ${r.totalSeats} seats left"
    }

    private fun color(ctx: Context, id: Int) = ContextCompat.getColor(ctx, id)

    fun rideColor(ctx: Context, s: RideStatus) = color(ctx, when (s) {
        RideStatus.OPEN -> R.color.status_open
        RideStatus.FULL -> R.color.status_full
        RideStatus.COMPLETED -> R.color.status_completed
        RideStatus.CANCELLED -> R.color.status_final
    })

    fun requestColor(ctx: Context, s: RequestStatus) = color(ctx, when (s) {
        RequestStatus.PENDING -> R.color.status_pending
        RequestStatus.ACCEPTED -> R.color.status_open
        RequestStatus.DECLINED, RequestStatus.CANCELLED -> R.color.status_final
    })

    fun badge(tv: TextView, text: String, color: Int) {
        tv.text = text
        tv.backgroundTintList = ColorStateList.valueOf(color)
    }

    /** Seat meter shows seats taken out of total. */
    fun seatMeter(m: LinearProgressIndicator, r: Ride) {
        m.max = r.totalSeats
        m.setIndicatorColor(rideColor(m.context, r.status))
        m.setProgressCompat(r.totalSeats - r.availableSeats, false)
    }
}
