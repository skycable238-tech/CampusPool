package com.ucbanilad.campuspool.ui

import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.snackbar.Snackbar
import com.ucbanilad.campuspool.data.MockRepository
import com.ucbanilad.campuspool.databinding.ActivityRideDetailsBinding
import com.ucbanilad.campuspool.model.RequestStatus
import com.ucbanilad.campuspool.model.RideStatus

class RideDetailsActivity : AppCompatActivity() {
    companion object { const val EXTRA_RIDE_ID = "extra_ride_id" }

    private lateinit var b: ActivityRideDetailsBinding
    private lateinit var rideId: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityRideDetailsBinding.inflate(layoutInflater)
        setContentView(b.root)
        title = "Ride details"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        rideId = intent.getStringExtra(EXTRA_RIDE_ID) ?: run { finish(); return }

        b.btnRequest.setOnClickListener {
            val out = MockRepository.requestSeat(rideId)
            Snackbar.make(b.root, out.message, Snackbar.LENGTH_LONG).show()
            render()
        }
    }

    override fun onResume() { super.onResume(); render() }

    override fun onSupportNavigateUp(): Boolean { finish(); return true }

    private fun render() {
        val r = MockRepository.getRide(rideId) ?: run { finish(); return }
        val me = MockRepository.currentUser
        val driver = MockRepository.getUser(r.driverId)
        val v = driver?.vehicle

        b.tvRoute.text = Ui.route(r)
        b.tvTime.text = Ui.dateTime(r.departureAt)
        Ui.badge(b.tvStatus, r.status.name, Ui.rideColor(this, r.status))
        b.tvSeats.text = Ui.seatsText(r)
        Ui.seatMeter(b.seatMeter, r)

        val vehicleText = if (v != null && v.model.isNotBlank())
            "${v.color} ${v.model} (${v.plateNumber})".trim() else "Not provided"
        b.tvDetails.text = buildString {
            append("Driver: ${r.driverName}\n")
            append("Vehicle: $vehicleText\n")
            append("Meeting point: ${r.meetingPoint}\n")
            append("Fare per seat: ${Ui.fare(r.farePerSeat)}")
            if (r.notes.isNotBlank()) append("\nNotes: ${r.notes}")
        }

        val mine = me?.let { MockRepository.myRequestFor(rideId, it.userId) }
        b.tvMyRequest.visibility = if (mine != null) View.VISIBLE else View.GONE
        if (mine != null) {
            b.tvMyRequest.text = "Your request: ${mine.status.name}"
            b.tvMyRequest.setTextColor(Ui.requestColor(this, mine.status))
        }

        val departed = r.departureAt <= System.currentTimeMillis()
        val active = mine != null && (mine.status == RequestStatus.PENDING || mine.status == RequestStatus.ACCEPTED)
        when {
            r.driverId == me?.userId -> { b.btnRequest.isEnabled = false; b.btnRequest.text = "This is your ride" }
            r.status == RideStatus.FULL -> { b.btnRequest.isEnabled = false; b.btnRequest.text = "Ride is full" }
            r.status != RideStatus.OPEN || departed -> { b.btnRequest.isEnabled = false; b.btnRequest.text = "Not available" }
            active -> { b.btnRequest.isEnabled = false; b.btnRequest.text = "Seat already requested" }
            else -> { b.btnRequest.isEnabled = true; b.btnRequest.text = "Request a seat" }
        }
    }
}
