package com.ucbanilad.campuspool.data

import android.util.Patterns
import com.ucbanilad.campuspool.model.*
import kotlin.math.abs

data class Outcome(val ok: Boolean, val message: String = "")

/**
 * Phase 1 in-memory repository. Mimics what Firestore transactions will do in Phase 2:
 * every seat change checks the rule and updates availableSeats in one step.
 */
object MockRepository {
    const val MINUTE = 60_000L
    const val HOUR = 60 * MINUTE
    const val MIN_LEAD = 30 * MINUTE          // BR-07
    const val CONFLICT_WINDOW = 60 * MINUTE   // BR-08
    const val MAX_SEATS = 6                   // BR-02

    private val users = mutableListOf<User>()
    private val passwords = mutableMapOf<String, String>()
    private val rides = mutableListOf<Ride>()
    private val requests = mutableListOf<RideRequest>()
    private var seq = 0

    var currentUser: User? = null
        private set

    init { seed() }

    private fun ok(m: String = "") = Outcome(true, m)
    private fun fail(m: String) = Outcome(false, m)
    private fun nextId(prefix: String) = "$prefix${++seq}"
    private fun now() = System.currentTimeMillis()
    private fun isActive(r: Ride) = r.status == RideStatus.OPEN || r.status == RideStatus.FULL

    // ---------------------------------------------------------------- auth
    fun login(email: String, password: String): Outcome {
        if (email.isBlank() || password.isBlank()) return fail("Enter your email and password")
        val u = users.firstOrNull { it.email.equals(email, true) }
        if (u == null || passwords[u.userId] != password) return fail("Invalid email or password")
        currentUser = u
        return ok("Welcome, ${u.fullName}")
    }

    fun logout() { currentUser = null }

    fun register(fullName: String, studentId: String, email: String, password: String, role: Role): Outcome {
        if (fullName.isBlank() || studentId.isBlank() || email.isBlank() || password.isBlank())
            return fail("Please fill in all required fields")
        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) return fail("Enter a valid email address")
        if (password.length < 6) return fail("Password must be at least 6 characters")
        if (users.any { it.studentId == studentId }) return fail("That student ID is already registered")
        if (users.any { it.email.equals(email, true) }) return fail("That email is already registered")
        val u = User(nextId("u"), fullName.trim(), email.trim(), studentId.trim(), "", role,
            if (role == Role.DRIVER) Vehicle("", "", "") else null, now())
        users.add(u)
        passwords[u.userId] = password
        currentUser = u
        return ok("Account created")
    }

    fun updateProfile(contact: String, vehicle: Vehicle?): Outcome {
        val u = currentUser ?: return fail("Please log in")
        val updated = u.copy(contactNumber = contact.trim(), vehicle = if (u.role == Role.DRIVER) vehicle else null)
        users[users.indexOfFirst { it.userId == u.userId }] = updated
        currentUser = updated
        return ok("Profile saved")
    }

    fun getUser(id: String) = users.firstOrNull { it.userId == id }

    // ---------------------------------------------------------------- queries
    fun getRide(id: String) = rides.firstOrNull { it.rideId == id }
    fun getRequest(id: String) = requests.firstOrNull { it.requestId == id }

    /** FR-05: open/full upcoming rides, filtered by origin/destination text and day. */
    fun searchRides(query: String, day: Long?): List<Ride> {
        val q = query.trim()
        return rides.filter { isActive(it) && it.departureAt > now() }
            .filter { q.isEmpty() || it.origin.contains(q, true) || it.destination.contains(q, true) }
            .filter { day == null || sameDay(it.departureAt, day) }
            .sortedBy { it.departureAt }
    }

    fun ridesOfDriver(driverId: String, history: Boolean): List<Ride> =
        rides.filter { it.driverId == driverId && (isActive(it) != history) }
            .sortedBy { it.departureAt }

    fun requestsOfPassenger(passengerId: String): List<RideRequest> =
        requests.filter { it.passengerId == passengerId }.sortedByDescending { it.createdAt }

    fun requestsOfRide(rideId: String, status: RequestStatus): List<RideRequest> =
        requests.filter { it.rideId == rideId && it.status == status }.sortedBy { it.createdAt }

    fun acceptedCount(rideId: String) = requests.count { it.rideId == rideId && it.status == RequestStatus.ACCEPTED }

    fun pendingCountForDriver(driverId: String) = requests.count {
        it.driverId == driverId && it.status == RequestStatus.PENDING && getRide(it.rideId)?.let { r -> isActive(r) } == true
    }

    fun myRequestFor(rideId: String, passengerId: String) =
        requests.filter { it.rideId == rideId && it.passengerId == passengerId }
            .maxByOrNull { it.createdAt }

    private fun sameDay(a: Long, b: Long): Boolean {
        val ca = java.util.Calendar.getInstance().apply { timeInMillis = a }
        val cb = java.util.Calendar.getInstance().apply { timeInMillis = b }
        return ca.get(java.util.Calendar.YEAR) == cb.get(java.util.Calendar.YEAR) &&
            ca.get(java.util.Calendar.DAY_OF_YEAR) == cb.get(java.util.Calendar.DAY_OF_YEAR)
    }

    // ---------------------------------------------------------------- driver: rides
    /** Returns an error message, or null when the ride fields are valid (BR-02, 07, 08, 10). */
    private fun validateRide(
        origin: String, destination: String, meeting: String, departureAt: Long,
        total: Int?, fare: Double?, driverId: String, excludeId: String?, timeChanged: Boolean
    ): String? {
        if (origin.isBlank() || destination.isBlank() || meeting.isBlank())
            return "Origin, destination and meeting point are required"
        if (origin.trim().equals(destination.trim(), true)) return "Origin and destination must be different"
        if (total == null || total !in 1..MAX_SEATS) return "Total seats must be a whole number from 1 to $MAX_SEATS"
        if (fare == null || fare < 0) return "Fare must be zero or more"
        if (timeChanged && departureAt < now() + MIN_LEAD) return "The ride must depart at least 30 minutes from now"
        val clash = rides.any {
            it.driverId == driverId && it.rideId != excludeId && isActive(it) &&
                abs(it.departureAt - departureAt) < CONFLICT_WINDOW
        }
        if (clash) return "You already have an active ride departing within 60 minutes of this time"
        return null
    }

    fun postRide(
        origin: String, destination: String, meeting: String, departureAt: Long,
        total: Int?, fare: Double?, notes: String
    ): Outcome {
        val u = currentUser ?: return fail("Please log in")
        if (u.role != Role.DRIVER) return fail("Only drivers can post rides")
        validateRide(origin, destination, meeting, departureAt, total, fare, u.userId, null, true)
            ?.let { return fail(it) }
        rides.add(Ride(nextId("r"), u.userId, u.fullName, origin.trim(), destination.trim(), meeting.trim(),
            departureAt, total!!, total, fare!!, notes.trim(), RideStatus.OPEN, now()))
        return ok("Ride posted")
    }

    fun editRide(
        rideId: String, origin: String, destination: String, meeting: String, departureAt: Long,
        total: Int?, fare: Double?, notes: String
    ): Outcome {
        val u = currentUser ?: return fail("Please log in")
        val r = getRide(rideId) ?: return fail("Ride not found")
        if (r.driverId != u.userId) return fail("Only the ride's driver can edit it")
        if (!isActive(r)) return fail("Completed or cancelled rides cannot be edited")
        if (r.departureAt <= now()) return fail("Departure time has passed; the ride can no longer be edited")
        validateRide(origin, destination, meeting, departureAt, total, fare, u.userId, rideId,
            departureAt != r.departureAt)?.let { return fail(it) }
        val accepted = acceptedCount(rideId)
        if (total!! < accepted) return fail("Total seats cannot be lower than the $accepted passenger(s) already accepted")
        r.origin = origin.trim(); r.destination = destination.trim(); r.meetingPoint = meeting.trim()
        r.departureAt = departureAt; r.farePerSeat = fare!!; r.notes = notes.trim()
        r.totalSeats = total
        r.availableSeats = total - accepted
        r.status = if (r.availableSeats == 0) RideStatus.FULL else RideStatus.OPEN
        if (r.status == RideStatus.FULL) declinePending(r.rideId)
        return ok("Ride updated")
    }

    /** FR-04 / BR-09: cancelling a ride cancels all its pending and accepted requests. */
    fun cancelRide(rideId: String): Outcome {
        val u = currentUser ?: return fail("Please log in")
        val r = getRide(rideId) ?: return fail("Ride not found")
        if (r.driverId != u.userId) return fail("Only the ride's driver can cancel it")
        if (!isActive(r)) return fail("This ride is already ${r.status.name.lowercase()}")
        if (r.departureAt <= now()) return fail("A ride can only be cancelled before departure")
        r.status = RideStatus.CANCELLED
        requests.filter { it.rideId == rideId && (it.status == RequestStatus.PENDING || it.status == RequestStatus.ACCEPTED) }
            .forEach { it.status = RequestStatus.CANCELLED; it.respondedAt = now() }
        return ok("Ride cancelled")
    }

    /** FR-11: only after departure. */
    fun completeRide(rideId: String): Outcome {
        val u = currentUser ?: return fail("Please log in")
        val r = getRide(rideId) ?: return fail("Ride not found")
        if (r.driverId != u.userId) return fail("Only the ride's driver can complete it")
        if (!isActive(r)) return fail("This ride is already ${r.status.name.lowercase()}")
        if (r.departureAt > now()) return fail("You can mark a ride completed only after its departure time")
        r.status = RideStatus.COMPLETED
        requests.filter { it.rideId == rideId && it.status == RequestStatus.PENDING }
            .forEach { it.status = RequestStatus.CANCELLED; it.respondedAt = now() }
        return ok("Ride marked completed")
    }

    // ---------------------------------------------------------------- requests
    /** FR-06, BR-05, BR-06, BR-07. */
    fun requestSeat(rideId: String): Outcome {
        val u = currentUser ?: return fail("Please log in")
        if (u.role != Role.PASSENGER) return fail("Only passengers can request seats")
        val r = getRide(rideId) ?: return fail("Ride not found")
        if (r.driverId == u.userId) return fail("You cannot request your own ride")
        if (r.departureAt <= now()) return fail("The departure time has passed")
        if (r.status == RideStatus.FULL || r.availableSeats <= 0) return fail("Ride is full")
        if (r.status != RideStatus.OPEN) return fail("This ride is no longer open")
        if (requests.any { it.rideId == rideId && it.passengerId == u.userId &&
                (it.status == RequestStatus.PENDING || it.status == RequestStatus.ACCEPTED) })
            return fail("You already have an active request on this ride")
        requests.add(RideRequest(nextId("q"), rideId, u.userId, u.fullName, r.driverId, RequestStatus.PENDING, now()))
        return ok("Seat requested. Waiting for the driver's decision")
    }

    /** FR-07/08, BR-01, BR-03, BR-08: check + deduct together (a Firestore transaction in Phase 2). */
    fun acceptRequest(requestId: String): Outcome {
        val u = currentUser ?: return fail("Please log in")
        val q = getRequest(requestId) ?: return fail("Request not found")
        val r = getRide(q.rideId) ?: return fail("Ride not found")
        if (r.driverId != u.userId) return fail("Only the ride's driver can accept requests")
        if (q.status != RequestStatus.PENDING) return fail("Only pending requests can be accepted")
        if (!isActive(r)) return fail("This ride is no longer active")
        if (r.departureAt <= now()) return fail("The departure time has passed")
        if (r.availableSeats <= 0) return fail("Ride is full")
        val clash = requests.any {
            it.passengerId == q.passengerId && it.status == RequestStatus.ACCEPTED && it.requestId != q.requestId &&
                getRide(it.rideId)?.let { o -> isActive(o) && abs(o.departureAt - r.departureAt) < CONFLICT_WINDOW } == true
        }
        if (clash) return fail("${q.passengerName} already has an accepted ride within 60 minutes of this one")
        q.status = RequestStatus.ACCEPTED
        q.respondedAt = now()
        r.availableSeats -= 1
        if (r.availableSeats == 0) {
            r.status = RideStatus.FULL
            declinePending(r.rideId)
            return ok("Accepted. The ride is now FULL; remaining requests were declined")
        }
        return ok("Accepted. ${r.availableSeats} seat(s) left")
    }

    fun declineRequest(requestId: String): Outcome {
        val u = currentUser ?: return fail("Please log in")
        val q = getRequest(requestId) ?: return fail("Request not found")
        val r = getRide(q.rideId) ?: return fail("Ride not found")
        if (r.driverId != u.userId) return fail("Only the ride's driver can decline requests")
        if (q.status != RequestStatus.PENDING) return fail("Only pending requests can be declined")
        q.status = RequestStatus.DECLINED
        q.respondedAt = now()
        return ok("Request declined")
    }

    /** FR-09, BR-04: an accepted cancellation releases the seat; FULL goes back to OPEN. */
    fun cancelRequest(requestId: String): Outcome {
        val u = currentUser ?: return fail("Please log in")
        val q = getRequest(requestId) ?: return fail("Request not found")
        val r = getRide(q.rideId) ?: return fail("Ride not found")
        if (q.passengerId != u.userId) return fail("Only the owner can cancel a request")
        if (q.status != RequestStatus.PENDING && q.status != RequestStatus.ACCEPTED)
            return fail("This request can no longer be cancelled")
        if (r.departureAt <= now()) return fail("The ride has already departed")
        val wasAccepted = q.status == RequestStatus.ACCEPTED
        q.status = RequestStatus.CANCELLED
        q.respondedAt = now()
        if (wasAccepted && isActive(r)) {
            r.availableSeats = minOf(r.totalSeats, r.availableSeats + 1)
            if (r.status == RideStatus.FULL) r.status = RideStatus.OPEN
            return ok("Request cancelled. Your seat was released")
        }
        return ok("Request cancelled")
    }

    private fun declinePending(rideId: String) {
        requests.filter { it.rideId == rideId && it.status == RequestStatus.PENDING }
            .forEach { it.status = RequestStatus.DECLINED; it.respondedAt = now() }
    }

    // ---------------------------------------------------------------- sample data
    private fun seed() {
        val t = now()
        fun at(hours: Double) = t + (hours * HOUR).toLong()

        fun user(name: String, sid: String, email: String, phone: String, role: Role, v: Vehicle?): User {
            val u = User(nextId("u"), name, email, sid, phone, role, v, t)
            users.add(u); passwords[u.userId] = "123456"; return u
        }
        fun ride(d: User, o: String, dest: String, meet: String, hrs: Double, total: Int, avail: Int,
                 fare: Double, notes: String, st: RideStatus = RideStatus.OPEN): Ride {
            val r = Ride(nextId("r"), d.userId, d.fullName, o, dest, meet, at(hrs), total, avail, fare, notes, st, t)
            rides.add(r); return r
        }
        fun req(r: Ride, p: User, st: RequestStatus, minsAgo: Long) {
            requests.add(RideRequest(nextId("q"), r.rideId, p.userId, p.fullName, r.driverId, st,
                t - minsAgo * MINUTE, if (st == RequestStatus.PENDING) null else t - (minsAgo - 5) * MINUTE))
        }

        val mark = user("Mark Reyes", "24-1001", "driver@uc.edu", "0917 111 2222", Role.DRIVER, Vehicle("Toyota Vios", "Silver", "GAB 1234"))
        val ana = user("Ana Cruz", "24-1002", "ana@uc.edu", "0917 333 4444", Role.DRIVER, Vehicle("Honda City", "White", "NBC 5678"))
        val me = user("Newzel John Manginsay", "26244558", "passenger@uc.edu", "0917 555 6666", Role.PASSENGER, null)
        val juan = user("Juan Dela Cruz", "24-2001", "juan@uc.edu", "0918 100 0001", Role.PASSENGER, null)
        val maria = user("Maria Santos", "24-2002", "maria@uc.edu", "0918 100 0002", Role.PASSENGER, null)
        val paolo = user("Paolo Garcia", "24-2003", "paolo@uc.edu", "0918 100 0003", Role.PASSENGER, null)
        val liza = user("Liza Tan", "24-2004", "liza@uc.edu", "0918 100 0004", Role.PASSENGER, null)

        // Mark: 3-seat ride with 1 accepted and 3 pending -> accept 2 more to see FULL + auto-decline
        val r1 = ride(mark, "Lahug", "UC Banilad", "Gaisano Country Mall gate", 3.0, 3, 2, 40.0, "Leaving on time, AC on")
        req(r1, juan, RequestStatus.ACCEPTED, 90)
        req(r1, me, RequestStatus.PENDING, 40)
        req(r1, maria, RequestStatus.PENDING, 30)
        req(r1, liza, RequestStatus.PENDING, 20)
        ride(mark, "UC Banilad", "Mandaue", "UC Banilad main gate", 27.0, 4, 4, 35.0, "")
        // Mark: already departed -> demonstrates "Mark completed"
        val r6 = ride(mark, "UC Banilad", "Lahug", "UC Banilad main gate", -2.0, 3, 2, 30.0, "")
        req(r6, paolo, RequestStatus.ACCEPTED, 300)

        // Ana: FULL ride, and one where the demo passenger is accepted
        val r3 = ride(ana, "Talamban", "UC Banilad", "Talamban Elementary School", 5.0, 2, 0, 30.0, "", RideStatus.FULL)
        req(r3, paolo, RequestStatus.ACCEPTED, 200)
        req(r3, liza, RequestStatus.ACCEPTED, 180)
        val r4 = ride(ana, "Mandaue", "UC Banilad", "Parkmall lobby", 28.0, 4, 2, 45.0, "Two stops on the way")
        req(r4, me, RequestStatus.ACCEPTED, 600)
        req(r4, maria, RequestStatus.ACCEPTED, 500)
        val r5 = ride(ana, "Banilad", "Ayala Center", "Banilad Town Centre", 50.0, 3, 3, 25.0, "")
        req(r5, me, RequestStatus.DECLINED, 900)
    }
}
