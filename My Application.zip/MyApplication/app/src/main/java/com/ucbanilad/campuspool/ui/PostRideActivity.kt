package com.ucbanilad.campuspool.ui

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.snackbar.Snackbar
import com.ucbanilad.campuspool.data.MockRepository
import com.ucbanilad.campuspool.databinding.ActivityPostRideBinding
import java.util.Calendar

/** Post a new ride, or edit one when EXTRA_RIDE_ID is passed. */
class PostRideActivity : AppCompatActivity() {
    companion object { const val EXTRA_RIDE_ID = "extra_ride_id" }

    private lateinit var b: ActivityPostRideBinding
    private var editId: String? = null
    private val cal: Calendar = Calendar.getInstance().apply {
        add(Calendar.HOUR_OF_DAY, 2); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityPostRideBinding.inflate(layoutInflater)
        setContentView(b.root)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        editId = intent.getStringExtra(EXTRA_RIDE_ID)
        val existing = editId?.let { MockRepository.getRide(it) }
        if (existing != null && savedInstanceState == null) {
            b.etOrigin.setText(existing.origin)
            b.etDestination.setText(existing.destination)
            b.etMeeting.setText(existing.meetingPoint)
            b.etSeats.setText(existing.totalSeats.toString())
            b.etFare.setText(existing.farePerSeat.toString())
            b.etNotes.setText(existing.notes)
            cal.timeInMillis = existing.departureAt
        }
        title = if (existing != null) "Edit ride" else "Post a ride"
        b.btnSave.text = if (existing != null) "Save changes" else "Post ride"
        updateButtons()

        b.btnDate.setOnClickListener {
            DatePickerDialog(this, { _, y, m, d ->
                cal.set(y, m, d); updateButtons()
            }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
        }
        b.btnTime.setOnClickListener {
            TimePickerDialog(this, { _, h, min ->
                cal.set(Calendar.HOUR_OF_DAY, h); cal.set(Calendar.MINUTE, min); updateButtons()
            }, cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), false).show()
        }
        b.btnSave.setOnClickListener { save() }
    }

    override fun onSupportNavigateUp(): Boolean { finish(); return true }

    private fun updateButtons() {
        b.btnDate.text = "Date: ${Ui.day(cal.timeInMillis)}"
        b.btnTime.text = java.text.SimpleDateFormat("'Time:' h:mm a", java.util.Locale.getDefault()).format(cal.time)
    }

    private fun save() {
        val origin = b.etOrigin.text.toString()
        val dest = b.etDestination.text.toString()
        val meet = b.etMeeting.text.toString()
        val seats = b.etSeats.text.toString().trim().toIntOrNull()
        val fare = b.etFare.text.toString().trim().toDoubleOrNull()
        val notes = b.etNotes.text.toString()
        val at = cal.timeInMillis

        val out = editId?.let { MockRepository.editRide(it, origin, dest, meet, at, seats, fare, notes) }
            ?: MockRepository.postRide(origin, dest, meet, at, seats, fare, notes)
        if (out.ok) {
            Toast.makeText(this, out.message, Toast.LENGTH_SHORT).show()
            finish()
        } else {
            Snackbar.make(b.root, out.message, Snackbar.LENGTH_LONG).show()
        }
    }
}
