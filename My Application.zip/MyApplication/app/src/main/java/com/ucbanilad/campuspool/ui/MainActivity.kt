package com.ucbanilad.campuspool.ui

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.ucbanilad.campuspool.R
import com.ucbanilad.campuspool.data.MockRepository
import com.ucbanilad.campuspool.databinding.ActivityMainBinding
import com.ucbanilad.campuspool.model.Role

/** Role-based host: bottom navigation differs for Driver and Passenger. */
class MainActivity : AppCompatActivity() {
    companion object { const val EXTRA_ROLE = "extra_role" }

    private lateinit var b: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val user = MockRepository.currentUser
        if (user == null) { goToLogin(); return }

        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        val role = Role.valueOf(intent.getStringExtra(EXTRA_ROLE) ?: user.role.name)
        b.bottomNav.inflateMenu(if (role == Role.DRIVER) R.menu.nav_driver else R.menu.nav_passenger)
        b.bottomNav.setOnItemSelectedListener { show(it.itemId); true }
        if (savedInstanceState == null) b.bottomNav.selectedItemId = R.id.nav_home
    }

    fun navigateTo(itemId: Int) { b.bottomNav.selectedItemId = itemId }

    fun logout() {
        MockRepository.logout()
        goToLogin()
    }

    private fun goToLogin() {
        startActivity(Intent(this, LoginActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK))
        finish()
    }

    private fun show(itemId: Int) {
        val f: Fragment = when (itemId) {
            R.id.nav_home -> HomeFragment()
            R.id.nav_browse -> BrowseFragment()
            R.id.nav_requests -> MyRequestsFragment()
            R.id.nav_rides -> MyRidesFragment()
            else -> ProfileFragment()
        }
        supportFragmentManager.beginTransaction().replace(R.id.container, f).commit()
    }
}
