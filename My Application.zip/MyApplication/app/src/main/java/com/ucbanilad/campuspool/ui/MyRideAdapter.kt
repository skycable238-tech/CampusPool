package com.ucbanilad.campuspool.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.ucbanilad.campuspool.data.MockRepository
import com.ucbanilad.campuspool.databinding.ItemMyRideBinding
import com.ucbanilad.campuspool.model.RequestStatus
import com.ucbanilad.campuspool.model.Ride

class MyRideAdapter(private val onClick: (Ride) -> Unit) : RecyclerView.Adapter<MyRideAdapter.VH>() {
    private var items: List<Ride> = emptyList()

    fun submit(list: List<Ride>) { items = list; notifyDataSetChanged() }

    class VH(val b: ItemMyRideBinding) : RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(ItemMyRideBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun getItemCount() = items.size

    override fun onBindViewHolder(h: VH, position: Int) {
        val r = items[position]
        val taken = r.totalSeats - r.availableSeats
        h.b.tvRoute.text = Ui.route(r)
        h.b.tvTime.text = Ui.dateTime(r.departureAt)
        h.b.tvSeats.text = "$taken of ${r.totalSeats} seats taken"
        val pending = MockRepository.requestsOfRide(r.rideId, RequestStatus.PENDING).size
        h.b.tvPending.text = if (pending > 0) "$pending pending request(s)" else "No pending requests"
        Ui.badge(h.b.tvStatus, r.status.name, Ui.rideColor(h.b.root.context, r.status))
        Ui.seatMeter(h.b.seatMeter, r)
        h.b.root.setOnClickListener { onClick(r) }
    }
}
