package com.ucbanilad.campuspool.ui

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.snackbar.Snackbar
import com.ucbanilad.campuspool.data.MockRepository
import com.ucbanilad.campuspool.databinding.ActivityLoginBinding

class LoginActivity : AppCompatActivity() {
    private lateinit var b: ActivityLoginBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(b.root)
        title = "Log in"

        b.btnLogin.setOnClickListener {
            val out = MockRepository.login(b.etEmail.text.toString().trim(), b.etPassword.text.toString())
            if (out.ok) openMain() else Snackbar.make(b.root, out.message, Snackbar.LENGTH_LONG).show()
        }
        b.tvRegister.setOnClickListener { startActivity(Intent(this, RegisterActivity::class.java)) }
        b.btnDemoPassenger.setOnClickListener { fill("passenger@uc.edu") }
        b.btnDemoDriver.setOnClickListener { fill("driver@uc.edu") }
    }

    private fun fill(email: String) {
        b.etEmail.setText(email)
        b.etPassword.setText("123456")
    }

    private fun openMain() {
        val role = MockRepository.currentUser!!.role.name
        startActivity(Intent(this, MainActivity::class.java).putExtra(MainActivity.EXTRA_ROLE, role))
        finish()
    }
}
