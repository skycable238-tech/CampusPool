package com.ucbanilad.campuspool.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.ucbanilad.campuspool.databinding.ItemMyRequestBinding
import com.ucbanilad.campuspool.model.RequestStatus
import com.ucbanilad.campuspool.model.Ride
import com.ucbanilad.campuspool.model.RideRequest

data class RequestRow(val request: RideRequest, val ride: Ride)

class MyRequestAdapter(
    private val onOpen: (RequestRow) -> Unit,
    private val onCancel: (RequestRow) -> Unit
) : RecyclerView.Adapter<MyRequestAdapter.VH>() {
    private var items: List<RequestRow> = emptyList()

    fun submit(list: List<RequestRow>) { items = list; notifyDataSetChanged() }

    class VH(val b: ItemMyRequestBinding) : RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(ItemMyRequestBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun getItemCount() = items.size

    override fun onBindViewHolder(h: VH, position: Int) {
        val row = items[position]
        val q = row.request
        val r = row.ride
        h.b.tvRoute.text = Ui.route(r)
        h.b.tvTime.text = Ui.dateTime(r.departureAt)
        h.b.tvDriver.text = "Driver: ${r.driverName} · ${Ui.fare(r.farePerSeat)}"
        Ui.badge(h.b.tvStatus, q.status.name, Ui.requestColor(h.b.root.context, q.status))
        val cancellable = (q.status == RequestStatus.PENDING || q.status == RequestStatus.ACCEPTED) &&
            r.departureAt > System.currentTimeMillis()
        h.b.btnCancel.visibility = if (cancellable) View.VISIBLE else View.GONE
        h.b.btnCancel.setOnClickListener { onCancel(row) }
        h.b.root.setOnClickListener { onOpen(row) }
        h.b.root.alpha = if (q.status == RequestStatus.DECLINED || q.status == RequestStatus.CANCELLED) 0.6f else 1f
    }
}
