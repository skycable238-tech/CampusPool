package com.ucbanilad.campuspool.ui

import android.app.DatePickerDialog
import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.ucbanilad.campuspool.data.MockRepository
import com.ucbanilad.campuspool.databinding.FragmentBrowseBinding
import java.util.Calendar

class BrowseFragment : Fragment() {
    private var _b: FragmentBrowseBinding? = null
    private val b get() = _b!!
    private var dayFilter: Long? = null
    private val adapter = RideAdapter { ride ->
        startActivity(Intent(requireContext(), RideDetailsActivity::class.java)
            .putExtra(RideDetailsActivity.EXTRA_RIDE_ID, ride.rideId))
    }

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        _b = FragmentBrowseBinding.inflate(i, c, false)
        b.rvRides.layoutManager = LinearLayoutManager(requireContext())
        b.rvRides.adapter = adapter
        b.etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) = refresh()
        })
        b.btnDate.setOnClickListener {
            val cal = Calendar.getInstance()
            DatePickerDialog(requireContext(), { _, y, m, d ->
                dayFilter = Calendar.getInstance().apply { set(y, m, d, 12, 0, 0) }.timeInMillis
                refresh()
            }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
        }
        b.btnClearDate.setOnClickListener { dayFilter = null; refresh() }
        return b.root
    }

    override fun onResume() {
        super.onResume()
        requireActivity().title = "Browse rides"
        refresh()
    }

    private fun refresh() {
        val list = MockRepository.searchRides(b.etSearch.text.toString(), dayFilter)
        adapter.submit(list)
        b.tvEmpty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
        b.btnDate.text = dayFilter?.let { Ui.day(it) } ?: "Any date"
    }

    override fun onDestroyView() { super.onDestroyView(); _b = null }
}
