package com.ucbanilad.campuspool.ui

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.snackbar.Snackbar
import com.ucbanilad.campuspool.data.MockRepository
import com.ucbanilad.campuspool.databinding.FragmentMyRequestsBinding

class MyRequestsFragment : Fragment() {
    private var _b: FragmentMyRequestsBinding? = null
    private val b get() = _b!!

    private val adapter = MyRequestAdapter(
        onOpen = { row ->
            startActivity(Intent(requireContext(), RideDetailsActivity::class.java)
                .putExtra(RideDetailsActivity.EXTRA_RIDE_ID, row.ride.rideId))
        },
        onCancel = { row ->
            MaterialAlertDialogBuilder(requireContext())
                .setTitle("Cancel request?")
                .setMessage("${row.request.status.name} request for ${Ui.route(row.ride)}")
                .setPositiveButton("Cancel request") { _, _ ->
                    val out = MockRepository.cancelRequest(row.request.requestId)
                    Snackbar.make(b.root, out.message, Snackbar.LENGTH_LONG).show()
                    refresh()
                }
                .setNegativeButton("Keep", null)
                .show()
        }
    )

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        _b = FragmentMyRequestsBinding.inflate(i, c, false)
        b.rvRequests.layoutManager = LinearLayoutManager(requireContext())
        b.rvRequests.adapter = adapter
        return b.root
    }

    override fun onResume() {
        super.onResume()
        requireActivity().title = "My requests"
        refresh()
    }

    private fun refresh() {
        val u = MockRepository.currentUser ?: return
        val rows = MockRepository.requestsOfPassenger(u.userId).mapNotNull { q ->
            MockRepository.getRide(q.rideId)?.let { RequestRow(q, it) }
        }
        adapter.submit(rows)
        b.tvEmpty.visibility = if (rows.isEmpty()) View.VISIBLE else View.GONE
    }

    override fun onDestroyView() { super.onDestroyView(); _b = null }
}
